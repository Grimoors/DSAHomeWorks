#ifndef __MY_INT_ELEMENT
#define __MY_INT_ELEMENT

typedef int ElementType;

// To compare equality of the two elements passed as parameters
// This is a super easy function to write for basic data types !
int AreEqualElems(int a,int b); 

#endif
